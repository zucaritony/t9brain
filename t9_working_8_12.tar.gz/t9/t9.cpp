#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "letters.c"
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <set>
#include <fcntl.h>
#include <termios.h>
#include <string>

using namespace std;

char getcc();
int kbhit();
bool frocmp(string sub, string full);
string strlower(string str);

struct Compare {
	bool operator()(string a, string b) { return a.length() < b.length(); }
};

//template<typename T>
//bool set<T>::operator<(const T& s1) { return this->length() < s1.length(); }

//template<typename T>
//bool operator<(const char& one, const char& other) { return one.length() < other.length(); }

int main(int argc, char** argv) {
	//this is the function included in letters.c ...I didn't want to scroll through 25 lines of drivel all the time
	char* letters[10];
	make_letters(letters);
	
	//len is the length of the current string being scrutinized, or the number
	//of times that a number has been pressed to find the right word
	//used in backspace implementation
	unsigned int len = 0;
	
	//nletts is the number of letters in the letters[i] referenced string (ie #1's "abc" has 3 letters, nletts=3)
	//nump is "number pressed" and is the numerical representation of the numerical character grabbed by 'grab'
	char nump, nletts;
	
	//grab is the buffer for the character grab function. this is where the captured key value goes
	char grab;
	
	//reading from this file for all words... this is on an ubuntu 9.04 system
	//if you don't have this file, go find a dictionary file online that fits the following format:
	//alphabetical (or ASCIIbetical) order, and it can order them like A-Z-a-z or like the regular Aa-Zz
	ifstream dict;
	dict.open("/usr/share/dict/american-english");
	
	//must use a multiset because Compare orders them by string length, and the set
	//interprets this as only having 1 word at every length value (1 word with length 3, 1 of length 4, etc)
	//multiset lets you have as many of any length you want
	multiset<string, Compare> possible, poss_temp, curr_dict, dict_temp;

	//temporary location for the current dictionary word
	string dword;
	
	//nwords is just a word counter on the phrase string
	unsigned int nwords = 0;
	
	//phrase is the combination of all words type out so far
	string phrase = "";
	
	while(!kbhit());
	grab = getchar();
	while(!isdigit(grab)) { cout << "push a digit\n"; while(!kbhit()); grab = getchar(); }
	
	nump = atoi(&grab);
	
	cout << (int)nump << "-- got here\n";
		
	if(nump==0)
		nump==-1;
	else
		len++;
		
	cout << "before inf while\n";
	
	while(1) {
		nletts = strlen(letters[nump]);
		set<string>::iterator curr;
		
		if(len==1) {
			cout << "first letter of the word\n";
			string lower;
			for(int i=0; i<nletts; i++) {
				//only way to get C++ to actually add a character as a string...
				string dummy = "";
				dummy += letters[nump][i];
				possible.insert(dummy);
			}
			
			//speedup, plus the first while stanza, reduce the amount of comparisons being made
			//by skipping to the part of the dictionary whose words carry the correct first letter
			//and by skipping the letters that are no longer relevant, seeing as the dictionary is alphabetical
			unsigned short speedup = 0;
			
			//skip to the beginning of the relevant section of the dictionary
			//keep in mind that if I swapped the parts before and after the "&&", this would skip the first relevant word
			while(dict >> dword && tolower(dword[0]) != letters[nump][0]);
			
			//now, starting with the last word we just grabbed (the first relevant one)
			//we are going to store all of the words that have the correct first letter
			//and start skipping the letters we look for once we find the first one that doesn't work
			
			//this is set to do the full loop through the letters twice because of the ASCIIbetical nature of the dictionary
			bool capitals = true;
			do {			
				//speedup just makes it skip letters that are no longer relevant by starting i at a higher reference value
				for(int i=0+speedup; i<nletts; i++) {
				//	cout << "and here --- \'" << letters[nump][i] << "\'\n";
					if(tolower(dword[0]) == letters[nump][i]) {
						curr_dict.insert(dword);
						break;
					} else
						speedup++;
				}
				
				//here we reset it (should only happen once) once we get through the
				//capital letter words to deal with the lower case by fast forwarding
				if(speedup==nletts-1 && capitals) {
					speedup=0;
					capitals = false;
					
					//here is the fast forward...get to the beginning of the lower case letters
					while(dict >> dword && tolower(dword[0]) != letters[nump][0]);
				}
				
			} while(dict >> dword && speedup<nletts);
			
//			cout << curr_dict.size() << "\n";
		} else if(len>1) {
//			cout << "more than 2 letters\n";
			
			vector<bool> dict_list, poss_list;
			bool dict_use;
			set<string>::iterator dict_iter, poss_iter;
			int i, j;
			
			//make every possible combination of word prefixes, whether or not they are useful
			//and store them in the original 'possible' set
			for(curr = possible.begin(); curr != possible.end(); curr++) {
				poss_list.push_back(false);
				for(i=0; i<nletts; i++) {
					poss_temp.insert((*curr)+letters[nump][i]);
				}
			}
			possible.swap(poss_temp);
			poss_temp.clear();
			
//			cout << curr_dict.size() << "   updated possible\n";
			
			//i and j are the current locations in the 'possible' and 'curr_dict' sets for reference with their
			//removal-marking vector counterparts, 'poss_list' and 'dict_list' respectively
			for(i=0, dict_iter = curr_dict.begin(); dict_iter != curr_dict.end(); dict_iter++, i++) {
//				cout << "herehere\n";
				dict_list.push_back(false);
				for(j=0, poss_iter = possible.begin(); poss_iter != possible.end(); poss_iter++, j++) {
					//if we find a use for the possible word prefix and the dictionary word, we keep track of it
					if(frocmp((*poss_iter), (*dict_iter))) {
//						cout << poss_list.size() << "  " << dict_list.size() << "  found match\n";
						poss_list[j] = dict_list[i] = true;
					}
				}
			}
			
//			cout << "after that\n";
			for(i=0, curr = possible.begin(); curr != possible.end(); curr++, i++) {
				if(poss_list[i])
					poss_temp.insert((*curr));
			}
			
			//if we didn't find ANYTHING then we just ignore the last press
			if(poss_temp.size()>0) {
				possible.swap(poss_temp);
				poss_temp.clear();
			} else continue;

			for(i=0, curr = curr_dict.begin(); curr != curr_dict.end(); curr++, i++) {
				if(dict_list[i])
					dict_temp.insert((*curr));
			}
			curr_dict.swap(dict_temp);
			dict_temp.clear();
		}
		
//		cout << "hahahaha\n";
		bool setswitch;
		if(curr_dict.size() > 0) {
			curr = curr_dict.begin();
			setswitch = false;
		} else if(possible.size() > 0) {
			curr = possible.begin();
			setswitch = true;
		} else {
			cout << "neither list has any elements\n";
		}

		do {
			//here is where we would print the most likely word
			//for(int k=0; k<len; k++) cout << '\b';
//							cout << "this sucks\n";
			cout << "\n\"";
			if(nwords>0 && nump!=0)
				cout << phrase + ' ' + (*curr) << "\"\n";
			else if(nump!=0)
				cout << (*curr) << "\"\n";
			else
				cout << phrase << "\"\n";
		
			while(!kbhit());
			grab = getchar();
			if(isdigit(grab)) {
				nump = atoi(&grab);
				len++;
			} else
//				cout << (int)grab << "\n";
				nump = -1;
				
			if(nump==-1) {
				switch(grab) {
					//if they pushed the left arrow, we increment unless it's the end of the tape, in which case we loop around
					case 68:
		//				cout << "pushed left\n";
						if(setswitch && curr == possible.begin())
							curr = possible.end();
						else if(!setswitch && curr == curr_dict.begin()) {
							curr = curr_dict.end();
						}
						
						//we have to go backwards whether it's the end of the set or not, because the end iterator
						//points to one element past the last one so we have to go back to the last one
						curr--;							
						break;
						
					//if they pushed the right arrow, we decrement unless it's the end of the tape, in which case we loop around
					case 67:
						curr++;
						if(setswitch && curr == possible.end())
							curr = possible.begin();
						else if(!setswitch && curr == curr_dict.end())
							curr = curr_dict.begin();
							
						break;
						
					case 127:
						break;
						//this is a backspace...
				}
				//somebody pushed 0! this means we get to add this word and start the next
			} else if(nump==0) {
				if(nwords>0)
					phrase += " ";
					
				phrase += (*curr);
				
				nwords++;
				len = 0;
				dict.seekg(0, ios::beg);
				
				possible.clear();
				curr_dict.clear();
			}
		} while(nump==-1 || nump==0);
	}
	
//	printf("%d\n", nump);
	
	return 0;
}

string strlower(string str) {
	string into = "";
	unsigned int len = str.length();
	for(int i=0; i<len; i++)
		into += tolower(str[i]);
		
	return into;
}

bool frocmp(string sub, string full) {
	//cout << "inside frocmp\n";
	unsigned int lensub, lenfull;
	lensub = sub.length();
	lenfull = full.length();
	full = strlower(full);
	
//	cout << sub << "  " << full << "\n";
	
	if(lensub == lenfull) {
		return sub == full;
	} else {
		for(int i=0; i<lensub; i++) {
			if(sub[i] != full[i])
				return false;
		}
		return true;
	}
}

char getcc() {
	char grab;
	int error = read(STDIN_FILENO, &grab, 1);
	
	if(error != -1)
		return grab;
	else
		return -1;
}

int kbhit(void)
{
	struct termios oldt, newt;
	int ch;
	int oldf;

	tcgetattr(STDIN_FILENO, &oldt);
	newt = oldt;
	newt.c_lflag &= ~(ICANON | ECHO);
	tcsetattr(STDIN_FILENO, TCSANOW, &newt);
	oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
	fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);

	ch = getchar();

	tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
	fcntl(STDIN_FILENO, F_SETFL, oldf);

	if(ch != EOF)
	{
		ungetc(ch, stdin);
		return 1;
	}

	return 0;
}

