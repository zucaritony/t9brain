#!/bin/bash

g++ -c letters.c && g++ t9.cpp && ./a.out

