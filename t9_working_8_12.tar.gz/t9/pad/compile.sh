#!/bin/bash

g++ numpad.cpp -L/usr/bin/X11R6/lib -lX11
